# 172.96.172.2_10109 (Multiplayer) World Save - Snapshot Details
![Server Icon](../icon.png)

- **Time**: `Sun, 28 Dec 2025 01:48:29 -0800` (Timestamp: `1766915309110`)
- **Captured By**: `null`

## Singleplayer Capture
- **Source World Name**: `null`
- **Version**: `null`

This file was created by [WorldTools 1.2.8](https://github.com/Avanatiker/WorldTools/)
