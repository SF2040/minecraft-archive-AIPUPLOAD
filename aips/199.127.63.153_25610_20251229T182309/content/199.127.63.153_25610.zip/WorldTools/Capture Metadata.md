# 199.127.63.153_25610 (Multiplayer) World Save - Snapshot Details
![Server Icon](../icon.png)

- **Time**: `Mon, 29 Dec 2025 18:24:15 +0800` (Timestamp: `1767003855677`)
- **Captured By**: `null`

## Singleplayer Capture
- **Source World Name**: `null`
- **Version**: `null`

This file was created by [WorldTools 1.2.8](https://github.com/Avanatiker/WorldTools/)
