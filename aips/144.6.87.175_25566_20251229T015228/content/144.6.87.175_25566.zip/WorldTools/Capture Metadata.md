# 144.6.87.175_25566 (Multiplayer) World Save - Snapshot Details
![Server Icon](../icon.png)

- **Time**: `Mon, 29 Dec 2025 01:54:05 +0800` (Timestamp: `1766944445236`)
- **Captured By**: `null`

## Singleplayer Capture
- **Source World Name**: `null`
- **Version**: `null`

This file was created by [WorldTools 1.2.8](https://github.com/Avanatiker/WorldTools/)
