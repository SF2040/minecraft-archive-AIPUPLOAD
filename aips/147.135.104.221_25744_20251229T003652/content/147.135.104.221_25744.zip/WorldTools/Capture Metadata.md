# 147.135.104.221_25744 (Multiplayer) World Save - Snapshot Details
![Server Icon](../icon.png)

- **Time**: `Sun, 28 Dec 2025 08:38:28 -0800` (Timestamp: `1766939908132`)
- **Captured By**: `null`

## Singleplayer Capture
- **Source World Name**: `null`
- **Version**: `null`

This file was created by [WorldTools 1.2.8](https://github.com/Avanatiker/WorldTools/)
