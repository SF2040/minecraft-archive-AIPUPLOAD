# 162.55.5.218_25567 (Multiplayer) World Save - Snapshot Details
![Server Icon](../icon.png)

- **Time**: `Mon, 29 Dec 2025 15:19:00 +0800` (Timestamp: `1766992740202`)
- **Captured By**: `null`

## Singleplayer Capture
- **Source World Name**: `null`
- **Version**: `null`

This file was created by [WorldTools 1.2.8](https://github.com/Avanatiker/WorldTools/)
