# 163.44.122.140_25565 (Multiplayer) World Save - Snapshot Details
![Server Icon](../icon.png)

- **Time**: `Wed, 31 Dec 2025 22:54:29 +0800` (Timestamp: `1767192869771`)
- **Captured By**: `null`

## Singleplayer Capture
- **Source World Name**: `null`
- **Version**: `null`

This file was created by [WorldTools 1.2.8](https://github.com/Avanatiker/WorldTools/)
