# 15.204.44.62_20144 (Multiplayer) World Save - Snapshot Details
![Server Icon](../icon.png)

- **Time**: `Sun, 28 Dec 2025 08:40:11 -0800` (Timestamp: `1766940011831`)
- **Captured By**: `null`

## Singleplayer Capture
- **Source World Name**: `null`
- **Version**: `null`

This file was created by [WorldTools 1.2.8](https://github.com/Avanatiker/WorldTools/)
