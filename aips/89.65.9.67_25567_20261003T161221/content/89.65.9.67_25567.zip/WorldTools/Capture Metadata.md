# 89.65.9.67_25567 (Multiplayer) World Save - Snapshot Details
![Server Icon](../icon.png)

- **Time**: `Sat, 3 Oct 2026 16:12:44 +0800` (Timestamp: `1791015164879`)
- **Captured By**: `null`

## Singleplayer Capture
- **Source World Name**: `null`
- **Version**: `null`

This file was created by [WorldTools 1.2.8](https://github.com/Avanatiker/WorldTools/)
