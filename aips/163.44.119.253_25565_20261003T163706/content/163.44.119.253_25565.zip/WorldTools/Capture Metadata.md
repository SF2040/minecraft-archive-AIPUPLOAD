# 163.44.119.253_25565 (Multiplayer) World Save - Snapshot Details
![Server Icon](../icon.png)

- **Time**: `Sat, 3 Oct 2026 16:38:13 +0800` (Timestamp: `1791016693520`)
- **Captured By**: `null`

## Singleplayer Capture
- **Source World Name**: `null`
- **Version**: `null`

This file was created by [WorldTools 1.2.8](https://github.com/Avanatiker/WorldTools/)
